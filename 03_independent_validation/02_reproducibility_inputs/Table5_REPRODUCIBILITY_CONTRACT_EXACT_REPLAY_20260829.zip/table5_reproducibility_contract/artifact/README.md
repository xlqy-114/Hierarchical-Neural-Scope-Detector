# Table 5 reproducibility contract and exact replay

## Scope and acceptance criterion

This package supports reviewer-facing reproducibility of the historical Table 5 result. It documents exact feature schemas, construction sources, preprocessing, model/OOF/threshold logic, consistency and veto logic, and independently replays the retained historical candidate decisions. It does **not** claim to refit every historical model from scratch, and it does not run OpenDriveVLA inference.

## Evidence audited

- v54 old-exact formal reference matrix and export contract;
- v59.3 current5 targeted-feature result package for seeds 955916-955920;
- v59.3 feature collection, export, sanitization, and hook-spec code;
- v61.4 current5 result package, including thresholds, OOF signals, candidate outcomes, and result tables;
- v61.4 OOF / consistency / veto / candidate-combination code.
- the v61.4 current5 focused report that names the nine A/B/C operating-point outcomes.

SHA-256 and source paths are recorded in `manifest.json`.

## Feature contract

- `schema/old_exact_2605_features.csv` is the exact old-exact column set selected by the retained v61 leakage filter from the v54 formal matrix.
- `schema/v59_targeted_7573_features.csv` lists every current5 targeted detector field. Its five sanitization representations are 1540 `clip__`, 1540 `slog1p__`, 1540 `miss__`, 1540 `extreme__`, and 1413 `safe_raw__` fields. The source matrix additionally retains six evaluation/identity columns: `seed`, `sample_id`, `row_source`, `exact_layer`, `harmful`, and `severe_harmful`.
- `schema/v59_high_risk_feature_columns.csv` retains the recorded high-risk decisions; training uses the sanitized, not raw, matrix.
- `source/` contains the exact archived Python and hook-spec files used to construct and audit these contracts.

## Training and decision protocol

The retained v61.4 code defines seed-level leave-one-seed-out OOF across current5. For each held-out seed it fits on the remaining seeds, selects thresholds on training scores to meet recall targets 0.98 / 0.99 / 1.00, then uses the median fold threshold for OOF alarms. Numeric model inputs are converted to float64, non-finite values become missing, values are clipped to [-1e6, 1e6], median-imputed, variance-filtered, and optionally SelectKBest-filtered. The candidate models are ExtraTrees (160 trees, depth 5, min leaf 3, balanced_subsample) and HistGradientBoosting (100 iterations, learning rate 0.06, 15 leaves, L2 0.05).

Consistency signals use held-out-seed robust top-5 absolute z-score summaries, where scale is MAD-derived with standard-deviation fallback. Their train-seed quantile thresholds are retained in `policy/v61_consistency_thresholds.csv`. The conservative veto is the maximum of the two retained HGB detector scores, applied only to a base ExtraTrees alarm and parameterized by retained thresholds 0.005 / 0.01 / 0.02 / 0.05.

## Exact replay result

Historical candidate grid rows retained in the source package: 134196

Replayed Table 5 operating-point candidate rows: 54

Exact matches: 54

Mismatches: 0

`replay/table5_replay_vs_historical.csv` compares each replayed operating-point candidate with the historical row. `policy/table5_reported_operating_points.csv` maps all nine reported A/B/C outcomes to their retained candidate set.

Some reported B/C outcomes have more than one outcome-equivalent candidate in the historical candidate table. This does not impede retrospective Table 5 reproduction: every retained Table 5 operating-point candidate is replayed. Before a future scene-disjoint or new-seed test, one exact candidate name, consistency signal, and veto threshold must be frozen prospectively.

## Sanitization audit

The retained v59 audit summary is copied as `evidence/v59_targeted_feature_audit_summary.json`. Its key checks are: {"high_risk_feature_count": 127, "leakage_bad_feature_name_count": 0, "pass_features": true, "pass_finite": true, "pass_leakage": true, "pass_rows": true, "rows": 6000, "seeds": ["955916", "955917", "955918", "955919", "955920"], "targeted_feature_count_by_group": {"D_LLM_targeted": 318, "D_out_boundary": 106, "S4_targeted": 1116}, "targeted_feature_count_total": 1540}
