#!/usr/bin/env python3
"""Build a portable Table 5 reproducibility contract and exact OOF replay.

This tool intentionally does not re-run OpenDriveVLA or refit historical models.
It audits the retained feature/schema, policy, OOF-signal, and result artifacts and
replays every retained candidate that realizes a reported Table 5 operating point.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import shutil
import tarfile
import zipfile
from collections import Counter
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple


DEFAULTS = {
    "v54_results": r"H:\Problem4\New_S_detector\FullS\v54\v54_4_formal_10seeds_compact_analysis_v2_for_return.tar.gz",
    "v59_results": r"H:\Problem4\New_S_detector\FullS\v59_3_targeted_feature_formal_additional_5seeds_955916_955920_for_return.tar.gz",
    "v59_code": r"H:\Problem4\实验\Full_S\v59\v59_3_targeted_feature_smoke_pack.zip",
    "v61_results": r"H:\Problem4\New_S_detector\FullS\v61\v61_4_best_feature_consistency_probe_current5_955916_955920_for_return.tar.gz",
    "v61_code": r"H:\Problem4\实验\Full_S\v61\v61_4_best_feature_consistency_probe_pack.zip",
}
DEFAULT_FOCUSED_REPORT = r"H:\Problem4\New_S_detector\FullS\OpenDriveVLA_v61_4_current5_focused_report_v2.docx"

V54_MATRIX = (
    "20260518_v54_4_sample_inline_online_v35_1_scdout_multipolicy_formal_10seeds_pos800900/"
    "v54_online_exports/v54_online_deployable_feature_matrix.csv"
)
V59_SANITIZED = "v59_targeted_feature_audit/v59_targeted_feature_matrix_sanitized.csv"
V59_AUDIT = "v59_targeted_feature_audit/v59_targeted_feature_audit_summary.json"
V59_GROUPS = "v59_targeted_feature_audit/v59_targeted_feature_group_summary.csv"
V59_HIGH_RISK = "v59_targeted_feature_audit/v59_high_risk_feature_columns.csv"
V61_PREFIX = "v61_1_best_feature_consistency_probe_quickcheck/"
V61_SUMMARY = V61_PREFIX + "v61_1_summary.json"
V61_RESULTS = V61_PREFIX + "v61_1_best_feature_consistency_results_by_scope.csv"
V61_OOF = V61_PREFIX + "v61_1_oof_signal_table.csv"
V61_MODEL_RESULTS = V61_PREFIX + "v61_1_feature_model_oof_results_by_scope.csv"
V61_THRESHOLDS = V61_PREFIX + "v61_1_consistency_thresholds.csv"
V61_GROUPS = V61_PREFIX + "v61_1_consistency_feature_group_summary.csv"

ID_COLS = {"seed", "sample_id", "raw_sample_id", "row_source", "exact_layer", "scope", "scope_group"}
ALL_LABELS = {
    "harmful",
    "severe_harmful",
    "v31_old_harmful_compatible",
    "v31_heading_expanded_harmful_compatible",
    "v31_speed_alter_harmful_compatible",
    "v31_heading_speed_alter_harmful_compatible",
}
LEAK_PATTERNS = (
    "harmful", "label", "delta_", "collision", "gt_", "clean_", "fault_target",
    "fault_scope", "bit_op", "bit_count", "is_positive", "effective", "applied",
    "attempted", "fault0_", "det_fault",
)
BASE_ALARM = "alarm__lineA_old_extra_trees_high_recall_online_all_no_temporal"

# The focused v61.4 report retains these nine reported operating-point outcomes.
REPORT_POINTS = (
    ("harmful", "A", "v35.1 ExtraTrees baseline", 205, 3, 27),
    ("harmful", "B", "v61.4 low-FAR policy", 205, 3, 8),
    ("harmful", "C", "near-99 recall fusion", 206, 2, 28),
    ("severe_harmful", "A", "v35.1 ExtraTrees baseline", 194, 1, 38),
    ("severe_harmful", "B", "v61.4 low-FAR policy", 194, 1, 18),
    ("severe_harmful", "C", "100% recall fusion", 195, 0, 38),
    ("v31_speed_alter_harmful_compatible", "A", "v35.1 ExtraTrees baseline", 205, 4, 27),
    ("v31_speed_alter_harmful_compatible", "B", "score-HGB low-FAR policy", 205, 4, 7),
    ("v31_speed_alter_harmful_compatible", "C", "near-99 recall v61.4 fusion", 207, 2, 37),
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def tar_member_stream(archive: Path, wanted_member: str):
    """Yield an opened member from a gzip tar without indexing the whole archive.

    The v54 reference archive is large.  Streaming avoids a full archive index solely
    to read the first CSV header, while preserving read-only access to the source.
    """
    with tarfile.open(archive, "r|gz") as tf:
        for member in tf:
            if member.name != wanted_member:
                continue
            extracted = tf.extractfile(member)
            if extracted is None:
                raise FileNotFoundError(f"{wanted_member} is not a regular file in {archive}")
            yield extracted
            return
    raise FileNotFoundError(f"{wanted_member} not found in {archive}")


def tar_text(archive: Path, member: str) -> str:
    for extracted in tar_member_stream(archive, member):
        return extracted.read().decode("utf-8", errors="replace")
    raise AssertionError("unreachable")


def tar_csv_rows(archive: Path, member: str) -> List[Dict[str, str]]:
    return list(csv.DictReader(io.StringIO(tar_text(archive, member))))


def tar_csv_header(archive: Path, member: str) -> List[str]:
    for extracted in tar_member_stream(archive, member):
        # tarfile's streaming reader is intentionally non-seekable; the header is a
        # single CSV record, so parse only that record rather than wrapping it in a
        # seek-aware TextIOWrapper.
        header_line = extracted.readline().decode("utf-8", errors="replace")
        return next(csv.reader([header_line]))
    raise AssertionError("unreachable")


def zip_text(archive: Path, member: str) -> str:
    with zipfile.ZipFile(archive) as zf:
        return zf.read(member).decode("utf-8", errors="replace")


def is_feature_column(name: str) -> bool:
    if name in ID_COLS or name in ALL_LABELS:
        return False
    low = name.lower()
    if any(pattern in low for pattern in LEAK_PATTERNS):
        return name.startswith(("score__", "alarm__", "threshold__"))
    return True


def as_int(value: object) -> int:
    if value in (None, "", "nan", "NaN"):
        return 0
    return int(float(str(value)))


def scope_mask(row: Mapping[str, str], scope: str) -> bool:
    return scope == "ALL" or row.get("scope_group", "") == scope


def rate(numerator: int, denominator: int) -> Optional[float]:
    return numerator / denominator if denominator else None


def metrics(rows: Iterable[Mapping[str, str]], label: str, prediction: Sequence[int]) -> Dict[str, object]:
    selected = list(rows)
    y = [as_int(row.get(label, 0)) for row in selected]
    tp = sum(p == 1 and target == 1 for p, target in zip(prediction, y))
    fn = sum(p == 0 and target == 1 for p, target in zip(prediction, y))
    fp = sum(p == 1 and target == 0 for p, target in zip(prediction, y))
    tn = sum(p == 0 and target == 0 for p, target in zip(prediction, y))
    return {
        "tp": tp, "fn": fn, "fp": fp, "tn": tn,
        "recall": rate(tp, tp + fn), "far": rate(fp, fp + tn), "precision": rate(tp, tp + fp),
        "total": len(selected), "positive_total": tp + fn, "negative_total": fp + tn,
    }


def prediction_for(row: Mapping[str, str], historical: Mapping[str, str]) -> int:
    base = as_int(row.get(BASE_ALARM, 0))
    model = as_int(row.get(historical.get("candidate_name", ""), 0))
    consistency = as_int(row.get(historical.get("consistency_signal", ""), 0))
    veto = as_int(row.get(historical.get("veto_signal", ""), 0))
    combination = historical.get("combination", "")
    if combination == "base_only":
        return base
    if combination == "model_only":
        return model
    if combination == "base_or_model":
        return max(base, model)
    if combination == "model_or_consistency":
        return max(model, consistency)
    if combination == "base_or_model_or_consistency":
        return max(base, model, consistency)
    if combination == "base_or_model_or_consistency_and_not_veto":
        return int(max(base, model, consistency) == 1 and veto == 0)
    if combination == "base_or_model_and_not_veto":
        return int(max(base, model) == 1 and veto == 0)
    if combination == "base_or_consistency":
        return max(base, consistency)
    if combination == "base_or_consistency_and_not_veto":
        return int(max(base, consistency) == 1 and veto == 0)
    raise ValueError(f"Unsupported combination: {combination!r}")


def base_reference_prediction(row: Mapping[str, str], historical: Mapping[str, str]) -> Optional[int]:
    candidate_type = historical.get("candidate_type", "")
    if candidate_type in {"baseline", "feature_model"}:
        return None
    base = as_int(row.get(BASE_ALARM, 0))
    model = as_int(row.get(historical.get("candidate_name", ""), 0))
    if candidate_type == "feature_model_plus_consistency":
        return model
    if candidate_type == "best_feature_base":
        return base
    if candidate_type.startswith("best_feature_base"):
        return max(base, model)
    if candidate_type.startswith("base_plus_consistency"):
        return base
    return None


def compare_values(expected: object, observed: object) -> bool:
    if expected in (None, ""):
        return True
    try:
        expected_float = float(str(expected))
        if observed is None:
            return False
        return math.isclose(expected_float, float(observed), rel_tol=0.0, abs_tol=1e-12)
    except ValueError:
        return str(expected) == str(observed)


def replay_results(oof_rows: List[Dict[str, str]], historical_rows: List[Dict[str, str]]) -> Tuple[List[Dict[str, object]], Dict[str, object]]:
    comparable_fields = (
        "tp", "fn", "fp", "tn", "recall", "far", "precision", "total", "positive_total", "negative_total",
        "base_tp", "base_fn", "base_fp", "base_recall", "base_far", "recovered_fn_vs_base",
        "added_fp_vs_base", "filtered_fp_vs_base", "vetoed_tp_vs_base",
    )
    comparisons: List[Dict[str, object]] = []
    unsupported = 0
    for historical in historical_rows:
        scope = historical["scope"]
        subset = [row for row in oof_rows if scope_mask(row, scope)]
        try:
            pred = [prediction_for(row, historical) for row in subset]
        except ValueError:
            unsupported += 1
            continue
        observed = metrics(subset, historical["label"], pred)
        reference = [base_reference_prediction(row, historical) for row in subset]
        if reference[0] is not None:
            base = metrics(subset, historical["label"], [int(value) for value in reference])
            observed.update({
                "base_tp": base["tp"], "base_fn": base["fn"], "base_fp": base["fp"],
                "base_recall": base["recall"], "base_far": base["far"],
            })
            y = [as_int(row.get(historical["label"], 0)) for row in subset]
            observed.update({
                "recovered_fn_vs_base": sum(b == 0 and p == 1 and target == 1 for b, p, target in zip(reference, pred, y)),
                "added_fp_vs_base": sum(b == 0 and p == 1 and target == 0 for b, p, target in zip(reference, pred, y)),
                "filtered_fp_vs_base": sum(b == 1 and p == 0 and target == 0 for b, p, target in zip(reference, pred, y)),
                "vetoed_tp_vs_base": sum(b == 1 and p == 0 and target == 1 for b, p, target in zip(reference, pred, y)),
            })
        mismatch_fields = [field for field in comparable_fields if not compare_values(historical.get(field, ""), observed.get(field))]
        comparisons.append({
            "candidate_type": historical["candidate_type"],
            "candidate_name": historical["candidate_name"],
            "combination": historical["combination"],
            "consistency_signal": historical.get("consistency_signal", ""),
            "veto_signal": historical.get("veto_signal", ""),
            "label": historical["label"],
            "scope": scope,
            "historical_tp": historical["tp"], "historical_fn": historical["fn"],
            "historical_fp": historical["fp"], "historical_tn": historical["tn"],
            "replay_tp": observed["tp"], "replay_fn": observed["fn"],
            "replay_fp": observed["fp"], "replay_tn": observed["tn"],
            "match": not mismatch_fields,
            "mismatch_fields": ";".join(mismatch_fields),
        })
    summary = {
        "historical_result_rows": len(historical_rows),
        "replayed_result_rows": len(comparisons),
        "unsupported_result_rows": unsupported,
        "exact_match_rows": sum(bool(row["match"]) for row in comparisons),
        "mismatch_rows": sum(not bool(row["match"]) for row in comparisons),
    }
    return comparisons, summary


def csv_write(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    for row in rows:
        for field in row:
            if field not in fields:
                fields.append(field)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def extract_source_files(v59_code: Path, v61_code: Path, target: Path) -> None:
    files = {
        "v59_inference_targeted_feature_audit.py": (
            v59_code,
            "v59_3_targeted_feature_smoke_pack/drivevla/inference_drivevla_subset1200_v59_online_targeted_feature_audit.py",
        ),
        "v59_feature_audit.py": (
            v59_code,
            "v59_3_targeted_feature_smoke_pack/tools_scan/audit_v59_targeted_features.py",
        ),
        "v54_export_matrices.py": (
            v59_code,
            "v59_3_targeted_feature_smoke_pack/tools_scan/export_v54_online_record_audit_matrices.py",
        ),
        "v59_targeted_stage_hook_specs.txt": (
            v59_code,
            "v59_3_targeted_feature_smoke_pack/resources/v59_targeted_stage_hook_specs.txt",
        ),
        "v61_oof_consistency_veto_probe.py": (
            v61_code,
            "v61_4_best_feature_consistency_probe_pack/tools_scan/run_v61_1_best_feature_consistency_probe.py",
        ),
    }
    target.mkdir(parents=True, exist_ok=True)
    for output_name, (archive, member) in files.items():
        (target / output_name).write_text(zip_text(archive, member), encoding="utf-8")


def report_operating_points(historical_rows: List[Dict[str, str]]) -> List[Dict[str, object]]:
    output = []
    for label, identifier, report_policy, tp, fn, fp in REPORT_POINTS:
        matches = [
            row for row in historical_rows
            if row.get("scope") == "ALL" and row.get("label") == label
            and as_int(row.get("tp")) == tp and as_int(row.get("fn")) == fn and as_int(row.get("fp")) == fp
        ]
        if identifier == "A":
            matches = [row for row in matches if row.get("candidate_type") == "baseline"]
        output.append({
            "label": label,
            "operating_point": identifier,
            "report_policy_name": report_policy,
            "tp": tp, "fn": fn, "fp": fp,
            "historical_candidate_matches": len(matches),
            "unique_combinations": " | ".join(sorted({str(row.get("combination", "")) for row in matches})),
            "policy_identity_status": (
                "unique" if len(matches) == 1 else "outcome-equivalent candidates retained; freeze one exact candidate before any new test"
            ),
        })
    return output


def reported_candidate_rows(historical_rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """Keep the historical candidates that exactly realize a displayed A/B/C outcome.

    Table 5 is a nine-row operating-point table, not the entire exploratory candidate
    grid (134k scope rows).  Replaying every configuration in that grid would add no
    reviewer-facing evidence and would obscure the actual acceptance target.  Where a
    displayed result has outcome-equivalent historical candidates, retain each of them.
    """
    targets = {(label, tp, fn, fp): identifier for label, identifier, _, tp, fn, fp in REPORT_POINTS}
    selected = []
    for row in historical_rows:
        key = (row.get("label"), as_int(row.get("tp")), as_int(row.get("fn")), as_int(row.get("fp")))
        if row.get("scope") != "ALL" or key not in targets:
            continue
        # A is explicitly the retained baseline in the focused report.  The matching
        # exploratory candidates for the same outcome are not alternative A policies.
        if targets[key] == "A" and row.get("candidate_type") != "baseline":
            continue
        selected.append(row)
    return selected


def render_readme(out_dir: Path, manifest: Dict[str, object], v59_audit: Dict[str, object], replay: Dict[str, object]) -> None:
    audit_digest = {
        "rows": v59_audit.get("rows"),
        "seeds": v59_audit.get("seeds"),
        "targeted_feature_count_total": v59_audit.get("targeted_feature_count_total"),
        "targeted_feature_count_by_group": v59_audit.get("targeted_feature_count_by_group"),
        "high_risk_feature_count": v59_audit.get("high_risk_feature_count"),
        "leakage_bad_feature_name_count": v59_audit.get("leakage_bad_feature_name_count"),
        "pass_rows": v59_audit.get("pass_rows"),
        "pass_features": v59_audit.get("pass_features"),
        "pass_finite": v59_audit.get("pass_finite"),
        "pass_leakage": v59_audit.get("pass_leakage"),
    }
    text = f"""# Table 5 reproducibility contract and exact replay

## Scope and acceptance criterion

This package supports reviewer-facing reproducibility of the historical Table 5 result. It documents exact feature schemas, construction sources, preprocessing, model/OOF/threshold logic, consistency and veto logic, and independently replays the retained historical candidate decisions. It does **not** claim to refit every historical model from scratch, and it does not run OpenDriveVLA inference.

## Evidence audited

- v54 old-exact formal reference matrix and export contract;
- v59.3 current5 targeted-feature result package for seeds 955916-955920;
- v59.3 feature collection, export, sanitization, and hook-spec code;
- v61.4 current5 result package, including thresholds, OOF signals, candidate outcomes, and result tables;
- v61.4 OOF / consistency / veto / candidate-combination code.
- the v61.4 current5 focused report that names the nine A/B/C operating-point outcomes.

SHA-256 and source paths are recorded in `manifest.json`.

## Feature contract

- `schema/old_exact_2605_features.csv` is the exact old-exact column set selected by the retained v61 leakage filter from the v54 formal matrix.
- `schema/v59_targeted_7573_features.csv` lists every current5 targeted detector field. Its five sanitization representations are 1540 `clip__`, 1540 `slog1p__`, 1540 `miss__`, 1540 `extreme__`, and 1413 `safe_raw__` fields. The source matrix additionally retains six evaluation/identity columns: `seed`, `sample_id`, `row_source`, `exact_layer`, `harmful`, and `severe_harmful`.
- `schema/v59_high_risk_feature_columns.csv` retains the recorded high-risk decisions; training uses the sanitized, not raw, matrix.
- `source/` contains the exact archived Python and hook-spec files used to construct and audit these contracts.

## Training and decision protocol

The retained v61.4 code defines seed-level leave-one-seed-out OOF across current5. For each held-out seed it fits on the remaining seeds, selects thresholds on training scores to meet recall targets 0.98 / 0.99 / 1.00, then uses the median fold threshold for OOF alarms. Numeric model inputs are converted to float64, non-finite values become missing, values are clipped to [-1e6, 1e6], median-imputed, variance-filtered, and optionally SelectKBest-filtered. The candidate models are ExtraTrees (160 trees, depth 5, min leaf 3, balanced_subsample) and HistGradientBoosting (100 iterations, learning rate 0.06, 15 leaves, L2 0.05).

Consistency signals use held-out-seed robust top-5 absolute z-score summaries, where scale is MAD-derived with standard-deviation fallback. Their train-seed quantile thresholds are retained in `policy/v61_consistency_thresholds.csv`. The conservative veto is the maximum of the two retained HGB detector scores, applied only to a base ExtraTrees alarm and parameterized by retained thresholds 0.005 / 0.01 / 0.02 / 0.05.

## Exact replay result

Historical candidate grid rows retained in the source package: {replay['historical_result_grid_rows']}

Replayed Table 5 operating-point candidate rows: {replay['replayed_result_rows']}

Exact matches: {replay['exact_match_rows']}

Mismatches: {replay['mismatch_rows']}

`replay/table5_replay_vs_historical.csv` compares each replayed operating-point candidate with the historical row. `policy/table5_reported_operating_points.csv` maps all nine reported A/B/C outcomes to their retained candidate set.

Some reported B/C outcomes have more than one outcome-equivalent candidate in the historical candidate table. This does not impede retrospective Table 5 reproduction: every retained Table 5 operating-point candidate is replayed. Before a future scene-disjoint or new-seed test, one exact candidate name, consistency signal, and veto threshold must be frozen prospectively.

## Sanitization audit

The retained v59 audit summary is copied as `evidence/v59_targeted_feature_audit_summary.json`. Its key checks are: {json.dumps(audit_digest, ensure_ascii=False, sort_keys=True)}
"""
    (out_dir / "README.md").write_text(text, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--focused-report", type=Path, default=Path(DEFAULT_FOCUSED_REPORT))
    for key, default in DEFAULTS.items():
        parser.add_argument(f"--{key.replace('_', '-')}", type=Path, default=Path(default))
    args = parser.parse_args()

    paths = {key: getattr(args, key) for key in DEFAULTS}
    missing = [str(path) for path in list(paths.values()) + [args.focused_report] if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing input archive(s):\n" + "\n".join(missing))

    out_dir: Path = args.output_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "schema").mkdir(exist_ok=True)
    (out_dir / "policy").mkdir(exist_ok=True)
    (out_dir / "replay").mkdir(exist_ok=True)
    (out_dir / "evidence").mkdir(exist_ok=True)
    shutil.copy2(args.focused_report, out_dir / "evidence" / args.focused_report.name)

    v54_header = tar_csv_header(paths["v54_results"], V54_MATRIX)
    old_exact = [name for name in v54_header if is_feature_column(name)]
    if len(old_exact) != 2605:
        raise RuntimeError(f"Expected 2605 old-exact columns, found {len(old_exact)}")
    csv_write(out_dir / "schema" / "old_exact_2605_features.csv", [
        {"index": index, "feature": feature} for index, feature in enumerate(old_exact)
    ])

    v59_header = tar_csv_header(paths["v59_results"], V59_SANITIZED)
    transforms = ("clip__", "slog1p__", "miss__", "extreme__", "safe_raw__")
    v59_rows = []
    for name in v59_header:
        prefix = next((item for item in transforms if name.startswith(item)), "")
        if prefix:
            v59_rows.append({"transform": prefix[:-2], "feature": name, "source_feature": name[len(prefix):]})
    transform_counts = Counter(row["transform"] for row in v59_rows)
    expected_transform_counts = {"clip": 1540, "slog1p": 1540, "miss": 1540, "extreme": 1540, "safe_raw": 1413}
    if dict(transform_counts) != expected_transform_counts:
        raise RuntimeError(f"Unexpected v59 transform counts: {dict(transform_counts)}")
    if len(v59_rows) != 7573:
        raise RuntimeError(f"Expected 7573 v59 detector fields, found {len(v59_rows)}")
    csv_write(out_dir / "schema" / "v59_targeted_7573_features.csv", v59_rows)
    csv_write(out_dir / "schema" / "v59_metadata_columns.csv", [
        {"column": name} for name in v59_header if name not in {row["feature"] for row in v59_rows}
    ])
    (out_dir / "schema" / "v59_transform_counts.json").write_text(
        json.dumps(dict(transform_counts), indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )

    v59_audit = json.loads(tar_text(paths["v59_results"], V59_AUDIT))
    v59_groups = tar_csv_rows(paths["v59_results"], V59_GROUPS)
    v59_high_risk = tar_csv_rows(paths["v59_results"], V59_HIGH_RISK)
    csv_write(out_dir / "schema" / "v59_feature_group_summary.csv", v59_groups)
    csv_write(out_dir / "schema" / "v59_high_risk_feature_columns.csv", v59_high_risk)
    (out_dir / "evidence" / "v59_targeted_feature_audit_summary.json").write_text(
        json.dumps(v59_audit, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8"
    )

    v61_summary = json.loads(tar_text(paths["v61_results"], V61_SUMMARY))
    v61_thresholds = tar_csv_rows(paths["v61_results"], V61_THRESHOLDS)
    v61_groups = tar_csv_rows(paths["v61_results"], V61_GROUPS)
    v61_model_results = tar_csv_rows(paths["v61_results"], V61_MODEL_RESULTS)
    historical_results = tar_csv_rows(paths["v61_results"], V61_RESULTS)
    oof_rows = tar_csv_rows(paths["v61_results"], V61_OOF)
    csv_write(out_dir / "policy" / "v61_consistency_thresholds.csv", v61_thresholds)
    csv_write(out_dir / "policy" / "v61_consistency_feature_group_summary.csv", v61_groups)
    csv_write(out_dir / "policy" / "v61_feature_model_oof_results_by_scope.csv", v61_model_results)
    (out_dir / "policy" / "v61_summary.json").write_text(
        json.dumps(v61_summary, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8"
    )

    oof_seed_counts = Counter(row["seed"] for row in oof_rows)
    if set(oof_seed_counts) != {"955916", "955917", "955918", "955919", "955920"} or set(oof_seed_counts.values()) != {1200}:
        raise RuntimeError(f"Unexpected OOF seed coverage: {dict(oof_seed_counts)}")
    report_candidates = reported_candidate_rows(historical_results)
    comparisons, replay_summary = replay_results(oof_rows, report_candidates)
    replay_summary["historical_result_grid_rows"] = len(historical_results)
    csv_write(out_dir / "replay" / "table5_replay_vs_historical.csv", comparisons)
    csv_write(out_dir / "replay" / "table5_replay_mismatches.csv", [row for row in comparisons if not row["match"]])
    replay_summary.update({"oof_rows": len(oof_rows), "oof_seed_counts": dict(sorted(oof_seed_counts.items()))})
    (out_dir / "replay" / "table5_exact_replay_summary.json").write_text(
        json.dumps(replay_summary, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8"
    )
    csv_write(out_dir / "policy" / "table5_reported_operating_points.csv", report_operating_points(historical_results))

    extract_source_files(paths["v59_code"], paths["v61_code"], out_dir / "source")
    manifest = {
        "purpose": "Table 5 reviewer-facing reproducibility contract and exact OOF replay",
        "acceptance_criterion": "Explain and replay the historical Table 5 feature/schema, OOF, threshold, consistency, veto, policy, and outcome chain without rerunning OpenDriveVLA or requiring from-scratch refitting.",
        "inputs": {
            key: {"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)}
            for key, path in paths.items()
        },
        "v54_old_exact": {"matrix_columns": len(v54_header), "exact_features": len(old_exact)},
        "v59_current5": {
            "matrix_columns": len(v59_header), "detector_features": len(v59_rows),
            "metadata_columns": [name for name in v59_header if name not in {row["feature"] for row in v59_rows}],
            "transform_counts": dict(transform_counts), "high_risk_rows": len(v59_high_risk),
        },
        "v61_current5": {"summary": v61_summary, "oof_seed_counts": dict(sorted(oof_seed_counts.items()))},
        "exact_replay": replay_summary,
        "caveat": "Retrospective Table 5 replay is complete from saved OOF signals. A prospective new-scene/new-seed test must name and freeze one exact candidate among any retained outcome-equivalent configurations before test labels are used.",
    }
    manifest["focused_report"] = {
        "path": str(args.focused_report), "bytes": args.focused_report.stat().st_size, "sha256": sha256(args.focused_report)
    }
    (out_dir / "manifest.json").write_text(
        json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True) + "\n", encoding="utf-8"
    )
    render_readme(out_dir, manifest, v59_audit, replay_summary)
    print(json.dumps({"output_dir": str(out_dir), "exact_replay": replay_summary}, ensure_ascii=False))


if __name__ == "__main__":
    main()
